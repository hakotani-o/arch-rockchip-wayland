#!/bin/bash

# カーネルイメージの格納ディレクトリ（必要に応じて /boot などに変更してください）
TARGET_DIR="/boot"

# 今回インストール/更新されたパッケージの正確なバージョン（例: 7.1.5-1）をpacmanから取得
PKG_VERSION=$(pacman -Q linux-aarch64-rockchip | awk '{print $2}')


# アーキテクチャや識別子を結合して、正しいカーネルバージョン文字列を作成
# 例: 7.1.5-1-aarch64-rockchip
KERNEL_VERSION="${PKG_VERSION}-aarch64-rockchip"


# デフォルトのinitramfsが存在する場合に実行
if [ -f "${TARGET_DIR}/initramfs-linux.img" ]; then
    mv "${TARGET_DIR}/initramfs-linux.img" "${TARGET_DIR}/initrd.img-${KERNEL_VERSION}"
    echo "Success: Renamed initramfs-linux.img to initrd.img-${KERNEL_VERSION}"
else
    echo "Warning:  ${TARGET_DIR}/initramfs-linux.img not found."
fi

